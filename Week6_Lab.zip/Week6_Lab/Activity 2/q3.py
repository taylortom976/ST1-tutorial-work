outfile = open('number_list.txt', 'w') 
for number in range(1, 101): 
    outfile.write(str(number) + '\n') 
outfile.close()