infile = open('number_list.txt', 'r')  
line = infile.readline()  
while line != '':  
    line = line.rstrip('\n') 
    number = int(line)  
    print(number) 
    line = infile.readline()  
infile.close()