#What will the following code display? 

values = [2] * 5  
print(values) 