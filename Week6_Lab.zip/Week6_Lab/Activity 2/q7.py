# Delete John Perez from the file.  
import os # Needed for the remove and rename functions  

def main():  
# Create a bool variable to use as a flag.  
    found = False  

    # Open the original students.txt file.  
    student_file = open('students.txt', 'r')  

    # Open the temporary file.  
    temp_file = open('temp.txt', 'w')  

    # Read the first record's name field.  
    name = student_file.readline()  

    # Read the rest of the file.  
    while name != '':  
        # Read the score field.  
        score = float(student_file.readline())  

        # Strip the \n from the name.  
        name = name.rstrip('\n')  

        # If this is not the record to delete, then  

        # write it to the temporary file.  

        if name != 'John Perez':  
            # Write the record to the temp file.  
            temp_file.write(name + '\n')  
            temp_file.write(str(score) + '\n')  
        else: 
            # Found the name. Set the found flag to True.  
            found = True  

        # Read the next name.  
        name = student_file.readline()  

    # Close the student file and the temporary file.  
    student_file.close()  
    temp_file.close()  

    # Delete the original students.txt file.  
    os.remove('students.txt')  

    # Rename the temporary file.  
    os.rename('temp.txt', 'students.txt')  

    # If the search value was not found in the file  

    # display a message.  

    if found:  
        print ('The file has been updated.')  
    else:  
        print ('That item was not found in the file.') 

    # Call the main function.  
main() 