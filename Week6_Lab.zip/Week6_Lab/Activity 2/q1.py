outfile = open('myName.txt', 'w')  
outfile.write('John Locke')  
outfile.close() 