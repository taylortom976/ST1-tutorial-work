names = ['John', 'Larry']

for element in names: 
    print(element) 