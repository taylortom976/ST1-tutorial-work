def list_total(arg): 
    total = 0 

    for val in arg: 
        total += val 
    return total
