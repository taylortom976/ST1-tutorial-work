mylist = [] 

for i in range(5): 
    mylist.append([]) 
    for j in range(3): 
        mylist[i].append(None) 

for i in range (len(mylist)): 
    for j in range (len(mylist[i])):    
        mylist[i][j] = input('Enter a value: ')