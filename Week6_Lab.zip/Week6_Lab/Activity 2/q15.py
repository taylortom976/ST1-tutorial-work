#What will the following code display? 

numbers = [1, 2, 3, 4, 5, 6, 7, 8]  
print(numbers[-4:]) 