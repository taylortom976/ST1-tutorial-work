infile = open('myName.txt', 'r') 
name = infile.read() 
print(name) 
infile.close() 