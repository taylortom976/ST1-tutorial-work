total = 0 
infile = open('number_list.txt', 'r')  
line = infile.readline()  
while line != '':  
    line = line.rstrip('\n') 
    number = int(line)  
    total += number 
    print(number) 
    line = infile.readline()  
infile.close() 
print('The total is:', total) 