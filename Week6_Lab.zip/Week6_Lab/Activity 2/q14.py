# What will the following code display? 

numbers = [5, 4, 3, 2, 1, 0]  
print(numbers[:3]) 