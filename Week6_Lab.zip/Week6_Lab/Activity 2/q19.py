names = ['Ruby']

if 'Ruby' in names: 
    print('Hello Ruby') 
else: 
    print('no Ruby') 