# Change Julie Milan's score to 100.  
import os # Needed for the remove and rename functions  
def main():  
# Create a bool variable to use as a flag.  
    found = False  

    # Open the original students.txt file.  
    student_file = open('students.txt', 'r')  

    # Open the temporary file.  
    temp_file = open('temp.txt', 'w') 

    # Read the first record's name field.  
    name = student_file.readline()  

    # Read the rest of the file.  
    while name != '':  

    # Read the score field.  
        score = float(student_file.readline())  

    # Strip the \n from the name.  
        name = name.rstrip('\n')  

    # If this is Julie Milan's, then write it with  
    # the new score to the temporary file. Otherwise,  
    # write the existing record to the temporary file.  
    if name == 'Julie Milan':  
    # Write the new record.  
        temp_file.write(name + '\n')  
        temp_file.write('100\n')  
    # Set the found flag to True.  
        found = True  
    else:  
        # Write the record to the temp file.  
        temp_file.write(name + '\n')  
        temp_file.write(str(score) + '\n')  
 
        name = student_file.readline()  
        student_file.close()  
        temp_file.close()    
        os.remove('students.txt')   
        os.rename('temp.txt', 'students.txt')  

        if found:  
            print('The file has been updated.' ) 
        else:  
            print('Julie Milan was not found in the file.' ) 
            main()