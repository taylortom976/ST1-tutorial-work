#What will list1 and list2 contain after the following statements are executed?  

list1 = [1, 2] * 2  
list2 = [3]  
list2 += list1 

print(list1)
print(list2)